@echo off
title Find Winning Products Fast
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8
echo.
echo  ============================================
echo    Find Winning Products Fast
echo    Created by Full Codes - github.com/full-codes
echo  ============================================
echo.
echo  Starting server on http://127.0.0.1:8765 ...
echo  (keep this window open - press Ctrl+C to stop)
echo.
start "" http://127.0.0.1:8765
runtime\python.exe -m app.main
pause
