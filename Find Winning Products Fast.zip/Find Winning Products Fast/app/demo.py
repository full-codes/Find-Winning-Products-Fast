"""Deterministic sample data, used ONLY when the user turns on Demo Mode.

Clearly labelled in the UI so it is never confused with real scraped data.
"""
from __future__ import annotations

import random

MARKET_ADJ = {
    "Etsy": ["Handmade", "Vintage", "Personalized", "Custom", "Boho", "Minimalist", "Rustic"],
    "AliExpress": ["Hot Sale", "Wholesale", "New", "DIY", "Nordic", "LED", "Portable"],
    "Amazon": ["Premium", "Best Selling", "Pro", "Ultimate", "Smart", "Eco-Friendly", "Classic"],
}
MARKET_NOUN = {
    "Etsy": ["Macrame Wall Hanging", "Custom Necklace", "Engraved Cutting Board", "Birth Flower Print",
             "Personalized Mug", "Baby Milestone Blanket", "Resin Coaster Set"],
    "AliExpress": ["Kitchen Gadget", "Pet Grooming Glove", "Mini Projector", "Car Organizer",
                   "Silicone Mold", "Fitness Band", "Sunset Lamp"],
    "Amazon": ["Standing Desk Mat", "Stainless Steel Water Bottle", "Weighted Blanket", "Air Fryer Liner",
               "Desk Organizer", "Sunrise Alarm Clock", "Resistance Band Set"],
}


def generate_demo(query: str, market: str, count: int = 18, seed: int | None = None) -> list[dict]:
    rng = random.Random(seed if seed is not None else hash(query + market) & 0xFFFF)
    adjs, nouns = MARKET_ADJ[market], MARKET_NOUN[market]
    products = []
    for i in range(count):
        price = round(rng.uniform(4.9, 89.0), 2)
        rating = round(rng.uniform(3.6, 5.0), 1)
        reviews = int(10 ** rng.uniform(1.7, 4.9))
        products.append({
            "id": f"demo-{market}-{i}",
            "marketplace": market,
            "title": f"{rng.choice(adjs)} {query.title()} {rng.choice(nouns).title()}",
            "price": price,
            "currency": "USD",
            "rating": rating,
            "reviews": reviews,
            "url": None,
            "image": None,
            "badge": rng.choice([None, None, "Best Seller", "Amazon's Choice"] if market == "Amazon" else [None]),
            "sponsored": False,
            "demo": True,
        })
    return products
