"""Winning-score engine.

Ranks products 0-100 by how "winning" they look, combining:
  - Popularity   (review / order volume, log-scaled)            38%
  - Quality      (average rating)                               30%
  - Price zone   (sweet-spot gaussian around ~$27)              18%
  - Revenue proxy(estimated lifetime gross revenue)             14%
"""
from __future__ import annotations

import math
from typing import Optional

REVIEW_TO_SALES = 8  # rough heuristic: 1 review ~ 8 real sales

WEIGHTS = {"popularity": 0.38, "quality": 0.30, "price_zone": 0.18, "revenue": 0.14}


def _clamp(x: float) -> float:
    return max(0.0, min(1.0, x))


def _popularity(reviews: int) -> float:
    if not reviews or reviews <= 0:
        return 0.0
    return _clamp(math.log10(reviews + 1) / 5.5)  # ~300k reviews -> 1.0


def _quality(rating: Optional[float]) -> float:
    if not rating:
        return 0.0
    return _clamp((rating - 3.5) / 1.5)  # 3.5 -> 0, 5.0 -> 1


def _price_zone(price: Optional[float]) -> float:
    if not price or price <= 0:
        return 0.0
    sigma = 18.0
    peak = 27.0
    return _clamp(math.exp(-((price - peak) ** 2) / (2 * sigma ** 2)))


def _revenue(reviews: int, price: Optional[float]) -> float:
    if not reviews or not price:
        return 0.0
    gross = reviews * price
    if gross <= 0:
        return 0.0
    return _clamp(math.log10(gross + 1) / 7.0)  # ~$10M gross -> 1.0


def estimate_sales(reviews: int) -> Optional[int]:
    if reviews and reviews > 0:
        return int(reviews * REVIEW_TO_SALES)
    return None


def score_product(product: dict) -> dict:
    """Add score + breakdown + estimate to a product dict (in place) and return it."""
    reviews = product.get("reviews") or product.get("favorites") or 0
    rating = product.get("rating")
    price = product.get("price")

    breakdown = {
        "popularity": round(100 * _popularity(reviews)),
        "quality": round(100 * _quality(rating)),
        "price_zone": round(100 * _price_zone(price)),
        "revenue": round(100 * _revenue(reviews, price)),
    }
    total = 100 * sum(WEIGHTS[k] * breakdown[k] / 100 for k in WEIGHTS)
    product["score"] = round(total)
    product["score_breakdown"] = breakdown
    # Sales/revenue estimates only make sense from real review counts;
    # Etsy favorites are used for popularity but not for revenue.
    product["est_sales"] = estimate_sales(product.get("reviews"))
    product["est_revenue"] = (
        round(product["est_sales"] * price, 0) if product["est_sales"] and price else None
    )
    return product


def score_all(products: list[dict]) -> list[dict]:
    return [score_product(p) for p in products]


SORT_KEYS = {
    "score": (lambda p: p.get("score") or 0, True),
    "price_asc": (lambda p: p.get("price") or 10**9, False),
    "price_desc": (lambda p: p.get("price") or 0, True),
    "reviews": (lambda p: p.get("reviews") or 0, True),
    "rating": (lambda p: p.get("rating") or 0, True),
}


def sort_products(products: list[dict], sort: str = "score") -> list[dict]:
    if sort not in SORT_KEYS:
        sort = "score"
    key, reverse = SORT_KEYS[sort]
    return sorted(products, key=key, reverse=reverse)
