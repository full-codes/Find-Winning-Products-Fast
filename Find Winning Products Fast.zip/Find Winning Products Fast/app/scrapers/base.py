"""Shared helpers for marketplace scrapers."""
from __future__ import annotations

import random
import re
from typing import Optional

import httpx


class ScrapeError(Exception):
    """Generic scraping failure."""


class ScrapeBlocked(ScrapeError):
    """Marketplace blocked us (captcha / consent wall / bot check)."""


USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
]

BASE_HEADERS = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Upgrade-Insecure-Requests": "1",
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Sec-Fetch-User": "?1",
}


def make_client() -> httpx.AsyncClient:
    """A client that looks like a normal browser visit."""
    headers = {**BASE_HEADERS, "User-Agent": random.choice(USER_AGENTS)}
    return httpx.AsyncClient(
        headers=headers,
        follow_redirects=True,
        timeout=httpx.Timeout(25.0, connect=10.0),
    )


def parse_price(text: Optional[str]) -> Optional[float]:
    """'$29.99' / 'US $12,34' / '12.99' -> 29.99"""
    if not text:
        return None
    m = re.search(r"(\d[\d.,\s]*[.,]\d{2})", text.replace("\xa0", " "))
    if not m:
        m = re.search(r"(\d[\d.,]*)", text)
    if not m:
        return None
    raw = m.group(1).replace(" ", "").replace("\u2009", "")
    # Handle both '1,234.56' and '1.234,56'
    if "," in raw and "." in raw:
        raw = raw.replace(",", "") if raw.rfind(".") > raw.rfind(",") else raw.replace(".", "").replace(",", ".")
    elif "," in raw:
        raw = raw.replace(",", ".")
    try:
        val = float(raw)
        return val if val > 0 else None
    except ValueError:
        return None


def parse_rating(text: Optional[str]) -> Optional[float]:
    """'4.6 out of 5 stars' -> 4.6"""
    if not text:
        return None
    m = re.search(r"(\d[.,]?\d*)", text)
    if not m:
        return None
    try:
        val = float(m.group(1).replace(",", "."))
        return val if 0 < val <= 5 else None
    except ValueError:
        return None


def parse_int(text: Optional[str]) -> Optional[int]:
    if not text:
        return None
    m = re.search(r"([\d,.\s]+)", text)
    if not m:
        return None
    digits = re.sub(r"[^\d]", "", m.group(1))
    try:
        return int(digits) if digits else None
    except ValueError:
        return None


def parse_k_count(text: Optional[str]) -> Optional[int]:
    """'(13.7K)' / '+ 2 K vendus' / '12,400' -> 13700 / 2000 / 12400"""
    if not text:
        return None
    m = re.search(r"([\d.,]+)\s*([KkMm])?", text)
    if not m:
        return None
    try:
        num = float(m.group(1).replace(",", ""))
        mult = {"k": 1_000, "m": 1_000_000}.get((m.group(2) or "").lower(), 1)
        return int(num * mult) if num > 0 else None
    except ValueError:
        return None


def extract_balanced_json(text: str, start: int, max_len: int = 4_000_000) -> Optional[str]:
    """Given an index of an opening '{' or '[', return the balanced JSON string."""
    open_ch = text[start]
    close_ch = {"{": "}", "[": "]"}[open_ch]
    depth = 0
    in_str = False
    escaped = False
    for i in range(start, min(len(text), start + max_len)):
        ch = text[i]
        if in_str:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
        elif ch == open_ch:
            depth += 1
        elif ch == close_ch:
            depth -= 1
            if depth == 0:
                return text[start : i + 1]
    return None
