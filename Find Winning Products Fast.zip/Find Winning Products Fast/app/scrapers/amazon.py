"""Amazon search scraper (best-effort direct scraping)."""
from __future__ import annotations

from typing import Optional

from bs4 import BeautifulSoup

from .base import ScrapeBlocked, make_client, parse_k_count, parse_price, parse_rating


def _amazon_captcha(html: str) -> bool:
    markers = (
        "Enter the characters you see below",
        "api-services-support@amazon.com",
        "To discuss automated access to Amazon data",
        "Please click the box below",
        "bm-verify=",          # bot-management interstitial (meta-refresh)
        "captcha-delivery",
    )
    return any(m in html for m in markers)


async def search(query: str, page: int = 1, country: str = "com") -> list[dict]:
    domain = {"com": "www.amazon.com", "ca": "www.amazon.ca", "de": "www.amazon.de",
              "uk": "www.amazon.co.uk", "fr": "www.amazon.fr"}.get(country, "www.amazon.com")
    url = f"https://{domain}/s"
    async with make_client() as client:
        resp = await client.get(
            url,
            params={"k": query, "page": str(page), "ref": "nb_sb_noss"},
        )
    if resp.status_code != 200:
        raise ScrapeBlocked(f"Amazon returned HTTP {resp.status_code} (likely bot check)")
    html = resp.text
    if _amazon_captcha(html) or len(html) < 5000:
        raise ScrapeBlocked("Amazon served a bot-check / robot verification page")

    soup = BeautifulSoup(html, "lxml")
    products: list[dict] = []
    for card in soup.select('div[data-component-type="s-search-result"], div[data-asin]'):
        asin = card.get("data-asin")
        if not asin:
            continue
        title_el = card.select_one("h2 a span") or card.select_one("h2 span") or card.select_one("[aria-label] h2")
        title = title_el.get_text(" ", strip=True) if title_el else ""
        if not title:
            continue

        price_el = card.select_one("span.a-price span.a-offscreen")
        price = parse_price(price_el.get_text() if price_el else None)

        rating = None
        reviews = None
        block = card.select_one('div[data-cy="reviews-block"]')
        if block:
            # New layout: plain number span + star icon alt + "(13.7K)" link
            num = block.select_one("span.a-color-base[aria-hidden='true']")
            if num:
                rating = parse_rating(num.get_text())
            if not rating:
                alt = block.select_one("span.a-icon-alt") or block.select_one("i span.a-icon-alt")
                if alt:
                    rating = parse_rating(alt.get_text())
            count_link = block.select_one('a[aria-label$="ratings"], a[href*="#customerReviews"]')
            if count_link:
                reviews = parse_k_count(count_link.get("aria-label"))
            if reviews is None:
                count_span = block.select_one("span.puis-normal-weight-text, span.s-underline-text")
                if count_span:
                    reviews = parse_k_count(count_span.get_text())
        if rating is None:  # older layout fallback
            alt = card.select_one("i.a-icon-star-small span.a-icon-alt") or card.select_one("i.a-icon-star span.a-icon-alt")
            if alt:
                rating = parse_rating(alt.get_text())

        img = card.select_one("img.s-image")
        image = img["src"] if img and img.has_attr("src") else None

        link = card.select_one("h2 a")
        href = link.get("href") if link else ""
        if href.startswith("/"):
            href = f"https://{domain}{href}"

        badge = card.select_one("span.puis-badge-label, span.a-badge-label")
        bestseller = badge.get_text(strip=True) if badge else None

        products.append({
            "id": asin,
            "marketplace": "Amazon",
            "title": title,
            "price": price,
            "currency": "USD",
            "rating": rating,
            "reviews": reviews,
            "url": href or f"https://{domain}/dp/{asin}",
            "image": image,
            "badge": bestseller,
            "sponsored": bool(card.select_one("span.puis-label-popover-default")) or "Sponsored" in title,
        })
    return products
