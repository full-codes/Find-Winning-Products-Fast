"""Etsy search scraper (best-effort direct scraping)."""
from __future__ import annotations

import json
import re
from typing import Optional

from bs4 import BeautifulSoup

from .base import ScrapeBlocked, make_client, parse_int, parse_price, parse_rating


def _walk_products(node) -> list[dict]:
    """Recursively collect objects that look like Product listings."""
    found: list[dict] = []
    if isinstance(node, dict):
        types = node.get("@type") or node.get("type")
        types = types if isinstance(types, list) else [types]
        if any(t in ("Product",) for t in types):
            found.append(node)
        else:
            for v in node.values():
                found.extend(_walk_products(v))
    elif isinstance(node, list):
        for v in node:
            found.extend(_walk_products(v))
    return found


def _offer_price(item: dict) -> Optional[float]:
    offers = item.get("offers")
    if isinstance(offers, list):
        offers = offers[0] if offers else None
    if isinstance(offers, dict):
        for key in ("price", "lowPrice", "highPrice"):
            if key in offers:
                try:
                    val = float(str(offers[key]).replace(",", ""))
                    if val > 0:
                        return val
                except ValueError:
                    pass
        spec = offers.get("priceSpecification")
        if isinstance(spec, dict) and "price" in spec:
            try:
                return float(str(spec["price"]).replace(",", "")) or None
            except (TypeError, ValueError):
                return None
    return None


def _aggregate(item: dict) -> tuple[Optional[float], Optional[int]]:
    agg = item.get("aggregateRating")
    if isinstance(agg, dict):
        rating = agg.get("ratingValue")
        count = agg.get("ratingCount") or agg.get("reviewCount")
        try:
            rating = float(str(rating).replace(",", "")) if rating else None
            count = int(str(count).replace(",", "")) if count else None
            return rating, count
        except (TypeError, ValueError):
            return None, None
    return None, None


async def search(query: str, page: int = 1) -> list[dict]:
    url = "https://www.etsy.com/search"
    async with make_client() as client:
        resp = await client.get(
            url,
            params={"q": query, "page": str(page), "explicit": "1"},
            headers={
                "Referer": "https://www.etsy.com/",
                "Sec-Fetch-Site": "same-origin",
            },
            cookies={"etsy_gdpr": "mde", "currency": "USD"},
        )
    if resp.status_code == 403:
        raise ScrapeBlocked(
            "Etsy blocks non-browser clients with DataDome bot protection (HTTP 403). "
            "Direct scraping from a desktop IP may work intermittently — retry later."
        )
    if resp.status_code != 200:
        raise ScrapeBlocked(f"Etsy returned HTTP {resp.status_code}")
    html = resp.text
    if "Please enable cookies" in html[:4000] or "One more step" in html[:4000]:
        raise ScrapeBlocked("Etsy served a bot check")

    soup = BeautifulSoup(html, "lxml")
    products: list[dict] = []
    seen_urls: set[str] = set()

    # Primary path: JSON-LD blocks embedded in the page
    for script in soup.find_all("script", type="application/ld+json"):
        try:
            data = json.loads(script.string or "")
        except (json.JSONDecodeError, TypeError):
            continue
        for item in _walk_products(data):
            url_ = item.get("url") or ""
            name = item.get("name") or ""
            if not name or url_ in seen_urls:
                continue
            seen_urls.add(url_)
            image = item.get("image")
            if isinstance(image, list):
                image = image[0] if image else None
            rating, count = _aggregate(item)
            products.append({
                "id": (re.search(r"/listing/(\d+)", url_) or [None, None])[1],
                "marketplace": "Etsy",
                "title": name,
                "price": _offer_price(item),
                "currency": "USD",
                "rating": rating,
                "reviews": count,
                "url": url_,
                "image": image,
                "badge": None,
                "sponsored": False,
            })

    # Fallback path: parse listing cards from HTML attributes
    if len(products) < 5:
        for card in soup.select("div[data-listing-id], li[data-listing-id], article[data-listing-id]"):
            listing_id = card.get("data-listing-id")
            title_el = card.select_one("h3, h2, [title]")
            title = (title_el.get("title") or title_el.get_text(" ", strip=True)) if title_el else ""
            if not title:
                continue
            price_el = card.select_one("[data-price], .currency-value")
            price = parse_price(price_el.get_text() if price_el else None)
            rating_el = card.select_one("span[aria-label*='out of 5'], .wt-icon-star + span")
            rating = parse_rating(rating_el.get("aria-label") if rating_el else None)
            rev_el = card.select_one("span[aria-label*='reviews'], .wt-text-caption")
            reviews = parse_int(rev_el.get_text() if rev_el else None)
            img = card.select_one("img[srcset], img[src]")
            image = img.get("src") if img else None
            products.append({
                "id": listing_id,
                "marketplace": "Etsy",
                "title": title,
                "price": price,
                "currency": "USD",
                "rating": rating,
                "reviews": reviews,
                "url": f"https://www.etsy.com/listing/{listing_id}" if listing_id else None,
                "image": image,
                "badge": None,
                "sponsored": False,
            })

    if not products:
        raise ScrapeBlocked("Etsy returned no parseable listings (layout changed or consent wall)")
    return products
