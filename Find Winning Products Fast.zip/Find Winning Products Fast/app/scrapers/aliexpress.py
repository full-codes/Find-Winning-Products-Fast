"""AliExpress search scraper (best-effort direct scraping).

AliExpress renders results from a big JSON blob embedded in the page
(window.__AER_DATA__ / similar). We locate that blob, pull out the item list
and read the price / rating / order-count fields tolerantly.
"""
from __future__ import annotations

import json
import re
from typing import Optional
from urllib.parse import quote_plus

from .base import (
    ScrapeBlocked,
    extract_balanced_json,
    make_client,
    parse_price,
    parse_rating,
)

MARKERS = ("window.__AER_DATA__", "window.runParams", '"mods"', "__INITIAL_STATE__")


def _find_data_blob(html: str) -> Optional[dict]:
    for marker in MARKERS:
        idx = html.find(marker)
        while idx != -1:
            brace = html.find("{", idx)
            if brace != -1 and brace - idx < 400:
                raw = extract_balanced_json(html, brace)
                if raw:
                    try:
                        return json.loads(raw)
                    except json.JSONDecodeError:
                        pass
            idx = html.find(marker, idx + 1)
    return None


def _deep_list(node, key_names=("itemList", "itemListModule", "products", "pageListModule")):
    """Find the first list that looks like products."""
    if isinstance(node, dict):
        for k, v in node.items():
            if k in key_names and isinstance(v, dict):
                content = v.get("content") or v.get("data")
                if isinstance(content, list):
                    return content
            if k in key_names and isinstance(v, list):
                return v
        for v in node.values():
            got = _deep_list(v, key_names)
            if got:
                return got
    elif isinstance(node, list):
        for v in node:
            got = _deep_list(v, key_names)
            if got:
                return got
    return None


def _parse_k_count(text: Optional[str]) -> Optional[int]:
    """'+ 2 K vendus' / '3.7K+ sold' / '12,400 sold' -> int"""
    if not text:
        return None
    m = re.search(r"([\d.,]+)\s*([KkMm])?", text)
    if not m:
        return None
    try:
        num = float(m.group(1).replace(",", ""))
        mult = {"k": 1_000, "m": 1_000_000}.get((m.group(2) or "").lower(), 1)
        return int(num * mult) if num > 0 else None
    except ValueError:
        return None


def _item_to_product(it: dict) -> Optional[dict]:
    title_raw = it.get("productTitle") or it.get("title") or it.get("itemTitle")
    if isinstance(title_raw, dict):  # {"displayTitle": "..."}
        title_raw = title_raw.get("displayTitle") or title_raw.get("title")
    if not title_raw or not isinstance(title_raw, str):
        return None

    item_id = it.get("productId") or it.get("itemId") or it.get("id")

    # prices: {"salePrice": {"minPrice": 3.51, "cent": 351, "currencyCode": "EUR", ...}}
    price = currency = None
    prices = it.get("prices") or {}
    for key in ("salePrice", "price", "discountPrice", "minPrice"):
        p = prices.get(key) if isinstance(prices, dict) else None
        if isinstance(p, dict):
            for sub in ("minPrice", "value", "formattedPrice"):
                val = p.get(sub)
                if val is None:
                    continue
                parsed = parse_price(str(val))
                if parsed:
                    price = parsed
                    currency = p.get("currencyCode") or "USD"
                    break
            if price:
                break

    # rating: {"evaluation": {"starRating": 4.1}}
    eval_ = it.get("evaluation") or {}
    rating = eval_.get("starRating") if isinstance(eval_, dict) else None
    if isinstance(rating, str):
        rating = parse_rating(rating)
    if not isinstance(rating, (int, float)):
        rating = None

    # orders: {"trade": {"tradeDesc": "+ 2 K vendus"}} or trace.utLogMap.real_trade_count
    trade = it.get("trade") or {}
    orders = _parse_k_count(trade.get("tradeDesc") if isinstance(trade, dict) else None)
    if not orders:
        trace = it.get("trace") or {}
        logs = trace.get("utLogMap") if isinstance(trace, dict) else None
        if isinstance(logs, dict):
            try:
                orders = int(str(logs.get("real_trade_count", "0")))
            except (TypeError, ValueError):
                orders = None

    image = None
    img = it.get("image")
    if isinstance(img, dict):
        image = img.get("imgUrl") or img.get("img")
    elif isinstance(img, str):
        image = img
    if isinstance(image, str) and image.startswith("//"):
        image = "https:" + image

    return {
        "id": str(item_id) if item_id else title_raw[:60],
        "marketplace": "AliExpress",
        "title": title_raw,
        "price": price,
        "currency": currency or "USD",
        "rating": rating,
        "reviews": orders,
        "orders": orders,
        "url": f"https://www.aliexpress.com/item/{item_id}.html" if item_id else None,
        "image": image,
        "badge": None,
        "sponsored": False,
    }


async def search(query: str, page: int = 1) -> list[dict]:
    url = f"https://www.aliexpress.com/w/wholesale-{quote_plus(query)}.html"
    async with make_client() as client:
        resp = await client.get(
            url,
            params={"SearchText": query, "page": str(page), "g": "y", "SortType": "default"},
            headers={"Referer": "https://www.aliexpress.com/", "Sec-Fetch-Site": "same-origin"},
            cookies={"aep_usuc_f": "region=US&currency=USD&site=glo&c_tp=USD"},  # force US locale / USD
        )
    if resp.status_code != 200:
        raise ScrapeBlocked(f"AliExpress returned HTTP {resp.status_code} (bot check / geo wall)")
    html = resp.text

    data = _find_data_blob(html)
    products: list[dict] = []
    if data:
        items = _deep_list(data) or []
        for it in items:
            if isinstance(it, dict):
                p = _item_to_product(it)
                if p:
                    products.append(p)

    # Last-resort regex fallback for title/price pairs
    if len(products) < 3:
        titles = re.findall(r'"(?:productTitle|displayTitle)":"((?:[^"\\]|\\.)*)"', html)
        prices = re.findall(r'"(?:salePrice|price)":\{[^{}]*?"minPrice":([\d.]+)', html)
        for i, t in enumerate(titles[:60]):
            try:  # proper JSON string unescaping (handles \u sequences)
                t = json.loads('"' + t + '"')
            except json.JSONDecodeError:
                continue
            products.append({
                "id": f"re-{i}",
                "marketplace": "AliExpress",
                "title": t,
                "price": float(prices[i]) if i < len(prices) else None,
                "currency": "USD",
                "rating": None,
                "reviews": None,
                "url": None,
                "image": None,
                "badge": None,
                "sponsored": False,
            })

    if not products:
        raise ScrapeBlocked("AliExpress returned no parseable products (JS-rendered page or bot check)")
    return products
