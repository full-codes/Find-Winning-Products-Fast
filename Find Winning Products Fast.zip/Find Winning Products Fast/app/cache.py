"""Tiny file-backed TTL cache so we don't re-hit marketplaces on repeat searches."""
from __future__ import annotations

import hashlib
import json
import threading
import time
from pathlib import Path


class TTLCache:
    def __init__(self, path: str | Path, ttl_seconds: int = 1800):
        self.path = Path(path)
        self.ttl = ttl_seconds
        self.lock = threading.Lock()
        self._load()

    def _load(self) -> None:
        try:
            self._data = json.loads(self.path.read_text("utf-8"))
        except (OSError, json.JSONDecodeError):
            self._data = {}

    def _save(self) -> None:
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.path.write_text(json.dumps(self._data, ensure_ascii=False), "utf-8")
        except OSError:
            pass

    def _purge(self) -> None:
        now = time.time()
        self._data = {k: v for k, v in self._data.items() if now - v.get("t", 0) < self.ttl}

    def get(self, key: str):
        with self.lock:
            entry = self._data.get(key)
            if not entry:
                return None
            if time.time() - entry.get("t", 0) > self.ttl:
                del self._data[key]
                return None
            return entry.get("d")

    def set(self, key: str, data) -> None:
        with self.lock:
            self._data[key] = {"t": time.time(), "d": data}
            self._purge()
            self._save()

    @staticmethod
    def make_key(*parts) -> str:
        raw = "|".join(str(p) for p in parts)
        return hashlib.sha1(raw.encode("utf-8")).hexdigest()
