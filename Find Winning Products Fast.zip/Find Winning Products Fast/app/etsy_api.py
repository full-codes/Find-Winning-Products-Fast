"""Etsy Open API v3 client — the reliable way to get real Etsy data.

Uses only an application keystring (no OAuth needed for public search).
Get one free at https://www.etsy.com/developers/register (takes ~2 minutes).
"""
from __future__ import annotations

from typing import Optional

import httpx

from .config import get as cfg_get
from .scrapers.base import ScrapeError, make_client

API_URL = "https://openapi.etsy.com/v3/application/listings/active"


def _map_listing(item: dict) -> dict:
    images = item.get("images") or []
    image = images[0].get("url_fullxfull") if images else None
    try:
        price = float(item.get("price")) if item.get("price") is not None else None
    except (TypeError, ValueError):
        price = None
    return {
        "id": str(item.get("listing_id") or ""),
        "marketplace": "Etsy",
        "title": item.get("title") or "",
        "price": price,
        "currency": item.get("currency_code") or "USD",
        "rating": None,           # not provided by the public API
        "reviews": None,
        "favorites": item.get("num_favorers") or 0,
        "url": item.get("url"),
        "image": image,
        "badge": "Bestseller" if item.get("state") == "active" and (item.get("num_favorers") or 0) >= 1000 else None,
        "sponsored": False,
    }


async def search_api(query: str, page: int = 1, limit: int = 50) -> list[dict]:
    key: Optional[str] = cfg_get("etsy_api_key")
    if not key:
        raise ScrapeError(
            "Etsy needs a free API key to work reliably (DataDome blocks direct scraping). "
            "Click the ⚙ Settings button in the dashboard and paste your Etsy keystring — "
            "get it free at https://www.etsy.com/developers/register"
        )
    async with make_client() as client:
        resp = await client.get(
            API_URL,
            params={"keywords": query, "limit": str(limit), "page": str(page), "includes": "Images:1"},
            headers={"x-api-key": key},
        )
    if resp.status_code in (401, 403):
        raise ScrapeError("Etsy rejected the API key — check the keystring in ⚙ Settings (it must be your app's keystring)")
    if resp.status_code == 429:
        raise ScrapeError("Etsy API rate limit reached (429) — wait a moment and retry")
    if resp.status_code != 200:
        raise ScrapeError(f"Etsy API returned HTTP {resp.status_code}")
    data = resp.json()
    return [_map_listing(r) for r in data.get("results", []) if r.get("title")]
