"""Simple local configuration stored in data/config.json (never hardcoded)."""
from __future__ import annotations

import json
import threading
from pathlib import Path

DATA = Path(__file__).resolve().parent.parent / "data"
CONFIG_PATH = DATA / "config.json"

_lock = threading.Lock()
_DEFAULTS: dict = {"etsy_api_key": ""}


def _read() -> dict:
    try:
        return {**_DEFAULTS, **json.loads(CONFIG_PATH.read_text("utf-8"))}
    except (OSError, json.JSONDecodeError):
        return dict(_DEFAULTS)


def get(key: str):
    with _lock:
        return _read().get(key)


def update(**kwargs) -> dict:
    with _lock:
        cfg = _read()
        cfg.update(kwargs)
        DATA.mkdir(parents=True, exist_ok=True)
        CONFIG_PATH.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), "utf-8")
        return cfg
