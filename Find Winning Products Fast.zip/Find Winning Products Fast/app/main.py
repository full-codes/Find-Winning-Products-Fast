r"""Find Winning Products Fast — backend server.

Run:  runtime\python.exe -m app.main
Then: http://127.0.0.1:8765
"""
from __future__ import annotations

import asyncio
import csv
import io
import logging
from pathlib import Path

import uvicorn
from fastapi import FastAPI, Query
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles

from .cache import TTLCache
from .config import get as cfg_get, update as cfg_update
from .demo import generate_demo
from .etsy_api import search_api as etsy_api_search
from .scrapers import aliexpress, amazon, etsy
from .scrapers.base import ScrapeError, ScrapeBlocked
from .scoring import score_all, sort_products

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("fwpf")

ROOT = Path(__file__).resolve().parent.parent
WEB = ROOT / "web"
DATA = ROOT / "data"

app = FastAPI(title="Find Winning Products Fast")
cache = TTLCache(DATA / "cache.json", ttl_seconds=1800)

MARKET_SCRAPERS = {
    "etsy": etsy.search,
    "amazon": amazon.search,
    "aliexpress": aliexpress.search,
}
MARKET_LABEL = {"etsy": "Etsy", "amazon": "Amazon", "aliexpress": "AliExpress"}


NEEDS_KEY_MSG = (
    "Etsy blocks direct scraping (DataDome). Click the ⚙ Settings button and paste a free "
    "Etsy API key to get real Etsy data — register at etsy.com/developers/register"
)


async def run_market(market: str, query: str, page: int, use_cache: bool) -> tuple[str, dict]:
    """Run one marketplace scrape; returns {'market':..., 'products'|'error'}."""
    key = cache.make_key(market, query, page)
    if use_cache:
        hit = cache.get(key)
        if hit is not None:
            if isinstance(hit, dict) and "products" in hit:
                return market, {"status": "cached", "products": hit["products"]}
            return market, {"status": "cached", "products": hit}  # legacy format
    try:
        if market == "etsy" and cfg_get("etsy_api_key"):
            products = await asyncio.wait_for(etsy_api_search(query, page), timeout=30)
        else:
            products = await asyncio.wait_for(MARKET_SCRAPERS[market](query, page), timeout=30)
    except ScrapeBlocked as e:
        return market, {"status": "blocked", "error": str(e), "products": []}
    except ScrapeError as e:
        return market, {"status": "error", "error": str(e), "products": []}
    except asyncio.TimeoutError:
        return market, {"status": "error", "error": "timed out after 30s", "products": []}
    except Exception as e:  # noqa: BLE001
        log.exception("unexpected error on %s", market)
        return market, {"status": "error", "error": str(e), "products": []}
    if not products:
        return market, {"status": "blocked", "error": "page returned no parseable products (bot check or layout change)", "products": []}
    cache.set(key, {"_status": "ok", "products": products})
    return market, {"status": "ok", "products": products}


def _apply_filters(products: list[dict], min_price, max_price, min_reviews) -> list[dict]:
    out = products
    if min_price is not None:
        out = [p for p in out if p.get("price") is not None and p["price"] >= min_price]
    if max_price is not None:
        out = [p for p in out if p.get("price") is not None and p["price"] <= max_price]
    if min_reviews:
        out = [p for p in out if (p.get("reviews") or 0) >= min_reviews]
    return out


@app.get("/api/search")
async def api_search(
    q: str = Query(..., min_length=1),
    markets: str = Query("etsy,amazon,aliexpress"),
    sort: str = Query("score"),
    min_price: float | None = None,
    max_price: float | None = None,
    min_reviews: int = 0,
    page: int = Query(1, ge=1, le=5),
    demo: bool = False,
):
    requested = [m.strip().lower() for m in markets.split(",") if m.strip().lower() in MARKET_SCRAPERS]
    if not requested:
        requested = list(MARKET_SCRAPERS)

    if demo:
        results = {m: {"status": "demo", "products": generate_demo(q, MARKET_LABEL[m])} for m in requested}
    else:
        has_etsy_key = bool(cfg_get("etsy_api_key"))
        results: dict = {}
        tasks = []
        for m in requested:
            if m == "etsy" and not has_etsy_key:
                results[m] = {"status": "needs_key", "error": NEEDS_KEY_MSG, "products": []}
            else:
                tasks.append(run_market(m, q, page, use_cache=True))
        if tasks:
            for m, r in await asyncio.gather(*tasks):
                results[m] = r

    all_products = []
    for m in requested:
        for p in results[m]["products"]:
            all_products.append(p)
    all_products = _apply_filters(all_products, min_price, max_price, min_reviews)
    all_products = score_all(all_products)
    all_products = sort_products(all_products, sort)

    return {
        "query": q,
        "demo": demo,
        "markets": {
            MARKET_LABEL[m]: {
                "status": results[m]["status"],
                "count": len(results[m]["products"]),
                **({"error": results[m]["error"]} if results[m].get("error") else {}),
            }
            for m in requested
        },
        "count": len(all_products),
        "products": all_products[:200],
    }


@app.get("/api/export")
async def api_export(
    q: str = Query(...),
    markets: str = Query("etsy,amazon,aliexpress"),
    demo: bool = False,
    format: str = Query("csv"),
):
    payload = await api_search(q=q, markets=markets, sort="score", page=1, demo=demo)
    if format != "csv":
        return payload
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["marketplace", "title", "price", "currency", "rating", "reviews",
                     "score", "est_sales", "est_revenue", "url"])
    for p in payload["products"]:
        writer.writerow([p.get("marketplace"), p.get("title"), p.get("price"), p.get("currency"),
                         p.get("rating"), p.get("reviews"), p.get("score"),
                         p.get("est_sales"), p.get("est_revenue"), p.get("url")])
    csv_data = buf.getvalue()
    filename = f"winning-products-{q.replace(' ', '_')[:40]}.csv"
    return Response(
        content=csv_data,
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@app.get("/api/config")
async def api_config_get():
    key = cfg_get("etsy_api_key") or ""
    return {"etsy_api_key_set": bool(key), "etsy_api_key_masked": (key[:6] + "…" + key[-4:]) if len(key) > 12 else ""}


@app.post("/api/config")
async def api_config_post(etsy_api_key: str = Query("", max_length=200)):
    cfg_update(etsy_api_key=etsy_api_key.strip())
    return await api_config_get()


@app.get("/")
async def index():
    return FileResponse(WEB / "index.html")


app.mount("/static", StaticFiles(directory=str(WEB)), name="static")


if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8765, log_level="info")
