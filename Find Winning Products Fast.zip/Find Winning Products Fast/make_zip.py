"""Rebuild the distribution zip with maximum compression."""
import os
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ZIP = ROOT.parent / "Find Winning Products Fast.zip"

EXCLUDE_DIRS = {"__pycache__"}
EXCLUDE_FILES = {"cache.json"}
EXCLUDE_EXT = {".pyc", ".pyo", ".log"}

count = 0
with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
    for dirpath, dirnames, filenames in os.walk(ROOT):
        dirnames[:] = [d for d in dirnames if d not in EXCLUDE_DIRS]
        for name in sorted(filenames):
            p = Path(dirpath) / name
            if name in EXCLUDE_FILES or p.suffix.lower() in EXCLUDE_EXT:
                continue
            zf.write(p, p.relative_to(ROOT.parent))
            count += 1

size_mb = ZIP.stat().st_size / (1024 * 1024)
print(f"files: {count}, zip size: {size_mb:.1f} MB -> {ZIP}")
