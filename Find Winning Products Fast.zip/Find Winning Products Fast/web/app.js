/* Find Winning Products Fast — dashboard logic */
"use strict";

const $ = (id) => document.getElementById(id);
const form = $("searchForm");
const queryInput = $("query");
const searchBtn = $("searchBtn");
const tableBody = $("tableBody");
const emptyState = $("emptyState");
const statusRow = $("statusRow");
const kpis = $("kpis");

let currentData = null;
let chartPrice = null;
let chartMarket = null;

const fmtMoney = (v) =>
  v == null ? "—" : "$" + Number(v).toLocaleString("en-US", { maximumFractionDigits: 0 });
const fmtInt = (v) => (v == null ? "—" : Number(v).toLocaleString("en-US"));
const esc = (s) =>
  String(s ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

function scoreClass(s) { return s >= 70 ? "hot" : s >= 40 ? "warm" : "cold"; }
function scoreColor(s) { return s >= 70 ? "#3fd08b" : s >= 40 ? "#ffb14a" : "#5b667a"; }

function setStatus(markets) {
  statusRow.innerHTML = "";
  for (const [name, info] of Object.entries(markets)) {
    const chip = document.createElement("span");
    chip.className = "status-chip " + info.status;
    const icon = { ok: "●", cached: "⏱", blocked: "⚠", error: "✖", demo: "✦", needs_key: "🔑" }[info.status] || "●";
    chip.textContent = `${icon} ${name}: ${info.status}${info.error ? "" : " (" + info.count + ")"}`;
    if (info.status === "needs_key") {
      chip.classList.add("blocked");
      chip.style.cursor = "pointer";
      chip.title = "Click to open Settings";
      chip.addEventListener("click", () => openSettings());
    } else if (info.error) {
      chip.title = info.error;
    }
    statusRow.appendChild(chip);
  }
}

function renderKpis(products) {
  const n = products.length;
  const prices = products.filter((p) => p.price).map((p) => p.price);
  const avgPrice = prices.length ? prices.reduce((a, b) => a + b, 0) / prices.length : null;
  const top = products[0];
  const mkts = new Set(products.map((p) => p.marketplace));
  const cards = [
    { label: "Products found", value: fmtInt(n) },
    { label: "Avg. price", value: avgPrice == null ? "—" : "$" + avgPrice.toFixed(2) },
    { label: "Top score", value: top ? top.score : "—", extra: top ? " / 100" : "" },
    { label: "Marketplaces", value: fmtInt(mkts.size) },
  ];
  kpis.innerHTML = cards
    .map((c) => `<div class="kpi"><div class="label">${c.label}</div><div class="value">${c.value}<small>${c.extra || ""}</small></div></div>`)
    .join("");
}

function renderTable(products) {
  tableBody.innerHTML = products
    .map((p, i) => {
      const img = p.image && /^https?:/.test(p.image)
        ? `<img class="thumb" src="${esc(p.image)}" loading="lazy" onerror="this.outerHTML='<div class=&quot;thumb-ph&quot;>📦</div>'">`
        : `<div class="thumb-ph">📦</div>`;
      const badge = p.badge ? `<span class="badge">${esc(p.badge)}</span>` : "";
      const demoBadge = p.demo ? `<span class="demo-badge">DEMO</span>` : "";
      const titleLink = p.url
        ? `<a href="${esc(p.url)}" target="_blank" rel="noopener">${esc(p.title)}</a>`
        : `<span>${esc(p.title)}</span>`;
      const meta = (p.favorites && !p.reviews)
        ? `<div class="meta">♥ ${fmtInt(p.favorites)} favorites</div>`
        : `<div class="meta">Est. sales ≈ ${p.est_sales ? fmtInt(p.est_sales) : "—"}</div>`;
      const rating = p.rating ? `★ ${p.rating.toFixed(1)}` : "—";
      const revs = p.reviews != null ? fmtInt(p.reviews) : "—";
      return `<tr>
        <td class="rank">${i + 1}</td>
        <td>${img}</td>
        <td class="ptitle">${titleLink}${badge}${demoBadge}
          ${meta}</td>
        <td><span class="mk ${esc(p.marketplace)}">${esc(p.marketplace)}</span></td>
        <td class="num">${p.price != null ? "$" + p.price.toFixed(2) : "—"}</td>
        <td class="num">${rating}</td>
        <td class="num">${revs}</td>
        <td class="num">${fmtMoney(p.est_revenue)}</td>
        <td class="num"><div class="score-wrap">
          <span class="score ${scoreClass(p.score)}">${p.score}</span>
          <div class="score-bar"><div style="width:${p.score}%;background:${scoreColor(p.score)}"></div></div>
        </div></td>
      </tr>`;
    })
    .join("");
  emptyState.classList.toggle("hidden", products.length > 0);
}

function renderCharts(products) {
  if (typeof Chart === "undefined") return; // offline: charts just stay empty

  // Score vs price scatter
  const pts = products.filter((p) => p.price != null);
  if (chartPrice) chartPrice.destroy();
  chartPrice = new Chart($("chartPrice"), {
    type: "scatter",
    data: {
      datasets: [{
        data: pts.map((p) => ({ x: p.price, y: p.score })),
        backgroundColor: "rgba(255,107,74,0.65)",
        pointRadius: 4,
      }],
    },
    options: {
      plugins: { legend: { display: false } },
      scales: {
        x: { title: { display: true, text: "Price ($)" }, ticks: { color: "#8b96a8" }, grid: { color: "#222b3a" } },
        y: { title: { display: true, text: "Score" }, min: 0, max: 100, ticks: { color: "#8b96a8" }, grid: { color: "#222b3a" } },
      },
    },
  });

  // Marketplace share
  const counts = {};
  for (const p of products) counts[p.marketplace] = (counts[p.marketplace] || 0) + 1;
  if (chartMarket) chartMarket.destroy();
  chartMarket = new Chart($("chartMarket"), {
    type: "doughnut",
    data: {
      labels: Object.keys(counts),
      datasets: [{
        data: Object.values(counts),
        backgroundColor: ["#e8658c", "#ff7a45", "#5aa9ff"],
        borderColor: "#161b22",
      }],
    },
    options: { plugins: { legend: { labels: { color: "#e6edf3", boxWidth: 12 } } }, cutout: "62%" },
  });
}

async function doSearch() {
  const q = queryInput.value.trim();
  if (!q) return;
  const markets = [...document.querySelectorAll("#marketChips input:checked")].map((c) => c.value);
  if (!markets.length) { alert("Select at least one marketplace."); return; }

  const params = new URLSearchParams({
    q,
    markets: markets.join(","),
    sort: $("sort").value,
    demo: $("demoMode").checked ? "1" : "0",
  });
  if ($("minPrice").value) params.set("min_price", $("minPrice").value);
  if ($("maxPrice").value) params.set("max_price", $("maxPrice").value);
  if ($("minReviews").value) params.set("min_reviews", $("minReviews").value);

  searchBtn.disabled = true;
  searchBtn.textContent = "Scanning…";
  try {
    const resp = await fetch("/api/search?" + params.toString());
    if (!resp.ok) throw new Error("Server error " + resp.status);
    currentData = await resp.json();
    setStatus(currentData.markets);
    renderKpis(currentData.products);
    renderTable(currentData.products);
    renderCharts(currentData.products);
  } catch (e) {
    statusRow.innerHTML = `<span class="status-chip error">✖ ${esc(e.message)} — is the server running?</span>`;
    tableBody.innerHTML = "";
    emptyState.classList.remove("hidden");
  } finally {
    searchBtn.disabled = false;
    searchBtn.textContent = "Find Winners";
  }
}

form.addEventListener("submit", (e) => { e.preventDefault(); doSearch(); });
$("sort").addEventListener("change", () => { if (currentData) doSearch(); });

/* ---------- Settings modal ---------- */
const settingsModal = $("settingsModal");

function openSettings() {
  settingsModal.classList.remove("hidden");
  refreshKeyState();
}
function closeSettings() { settingsModal.classList.add("hidden"); }

async function refreshKeyState() {
  try {
    const cfg = await (await fetch("/api/config")).json();
    const state = $("etsyKeyState");
    if (cfg.etsy_api_key_set) {
      state.textContent = "✓ key saved (" + cfg.etsy_api_key_masked + ")";
      state.style.color = "var(--good)";
    } else {
      state.textContent = "no key";
      state.style.color = "var(--muted)";
    }
    $("etsyKeyInput").value = "";
  } catch { /* server offline */ }
}

$("settingsBtn").addEventListener("click", openSettings);
$("settingsClose").addEventListener("click", closeSettings);
settingsModal.addEventListener("click", (e) => { if (e.target === settingsModal) closeSettings(); });

$("etsyKeySave").addEventListener("click", async () => {
  const key = $("etsyKeyInput").value.trim();
  if (!key) { $("etsyKeyInput").focus(); return; }
  await fetch("/api/config?etsy_api_key=" + encodeURIComponent(key), { method: "POST" });
  closeSettings();
  if (queryInput.value.trim()) doSearch();
});

$("etsyKeyClear").addEventListener("click", async () => {
  await fetch("/api/config?etsy_api_key=", { method: "POST" });
  refreshKeyState();
});

$("exportBtn").addEventListener("click", () => {
  const q = queryInput.value.trim() || "products";
  const markets = [...document.querySelectorAll("#marketChips input:checked")].map((c) => c.value).join(",");
  const params = new URLSearchParams({ q, markets, demo: $("demoMode").checked ? "1" : "0" });
  window.location.href = "/api/export?" + params.toString();
});

// Preload a friendly example so the first click is instant.
queryInput.value = "macrame wall hanging";
